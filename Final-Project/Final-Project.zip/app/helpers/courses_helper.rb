module CoursesHelper
end
